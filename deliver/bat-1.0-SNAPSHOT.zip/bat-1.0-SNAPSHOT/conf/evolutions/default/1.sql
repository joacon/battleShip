# --- Created by Ebean DDL
# To stop Ebean DDL generation, remove this comment and start using Evolutions

# --- !Ups

create table game_match (
  id                            bigint auto_increment not null,
  player1_id                    bigint,
  player2_id                    bigint,
  winner_id                     bigint,
  player1ready                  tinyint(1) default 0,
  player2ready                  tinyint(1) default 0,
  turn_id                       bigint,
  player1hits                   varchar(255),
  player2hits                   varchar(255),
  player1water                  varchar(255),
  player2water                  varchar(255),
  player1sinks                  varchar(255),
  player2sinks                  varchar(255),
  constraint pk_game_match primary key (id)
);

create table ship (
  id                            bigint auto_increment not null,
  game_match_id                 bigint not null,
  sunk                          tinyint(1) default 0,
  position                      varchar(255),
  hits                          varchar(255),
  constraint pk_ship primary key (id)
);

create table user (
  id                            bigint auto_increment not null,
  first_name                    varchar(255),
  last_name                     varchar(255),
  facebook_id                   bigint,
  wins                          bigint,
  total_matches                 bigint,
  constraint pk_user primary key (id)
);

create table nono (
  id                            bigint auto_increment not null,
  constraint pk_nono primary key (id)
);

alter table game_match add constraint fk_game_match_player1_id foreign key (player1_id) references user (id) on delete restrict on update restrict;
create index ix_game_match_player1_id on game_match (player1_id);

alter table game_match add constraint fk_game_match_player2_id foreign key (player2_id) references user (id) on delete restrict on update restrict;
create index ix_game_match_player2_id on game_match (player2_id);

alter table game_match add constraint fk_game_match_winner_id foreign key (winner_id) references user (id) on delete restrict on update restrict;
create index ix_game_match_winner_id on game_match (winner_id);

alter table game_match add constraint fk_game_match_turn_id foreign key (turn_id) references user (id) on delete restrict on update restrict;
create index ix_game_match_turn_id on game_match (turn_id);

alter table ship add constraint fk_ship_game_match_id foreign key (game_match_id) references game_match (id) on delete restrict on update restrict;
create index ix_ship_game_match_id on ship (game_match_id);


# --- !Downs

alter table game_match drop foreign key fk_game_match_player1_id;
drop index ix_game_match_player1_id on game_match;

alter table game_match drop foreign key fk_game_match_player2_id;
drop index ix_game_match_player2_id on game_match;

alter table game_match drop foreign key fk_game_match_winner_id;
drop index ix_game_match_winner_id on game_match;

alter table game_match drop foreign key fk_game_match_turn_id;
drop index ix_game_match_turn_id on game_match;

alter table ship drop foreign key fk_ship_game_match_id;
drop index ix_ship_game_match_id on ship;

drop table if exists game_match;

drop table if exists ship;

drop table if exists user;

drop table if exists nono;

